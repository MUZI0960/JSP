package kr.or.ddit.ui;

import kr.or.ddit.vo.Pagination;

public interface PaginationRenderer {
	public String renderPagination(Pagination pagination);
}
