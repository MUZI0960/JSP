package kr.or.ddit.validate;

public interface LoginGroup {

}
